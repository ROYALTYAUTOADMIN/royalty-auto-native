import express from "express";
import cors from "cors";
const app = express();
app.use(cors());
app.use(express.json());

app.post("/api/auth/login", (req, res) => {
  const { username } = req.body;
  res.json({ id: 1, username, role: "customer" });
});

app.listen(3000, () => console.log("Server running on port 3000"));