import React from "react";
import { TouchableOpacity, Text } from "react-native";

export default function Button({ title, onPress }: { title: string; onPress: () => void }) {
  return (
    <TouchableOpacity onPress={onPress} style={{ backgroundColor: "#DD0302", padding: 15, borderRadius: 10, alignItems: "center" }}>
      <Text style={{ color: "#fff", fontWeight: "bold" }}>{title}</Text>
    </TouchableOpacity>
  );
}